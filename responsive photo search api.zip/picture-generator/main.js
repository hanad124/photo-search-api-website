const imgContainer = document.querySelector(".imges");
const input = document.querySelector(".search-input");
const search_btn = document.querySelector(".search-btn");






// load Event 

window.addEventListener("DOMContentLoaded", (e) => {
  e.preventDefault();


  function GettingAllData(data){
    data.forEach(element => {
      // console.log(element.urls)
      imgContainer.innerHTML += `
      <img src=${element.urls.full} class="image">
      `
    });
  }

 fetch(`https://api.unsplash.com/search/photos/?query=popular&per_page=19&client_id=-GS_BgTXpa7T6831-Gc4UV0oYzU-P6C6OcKKZB5-rNs`)
     .then(response =>{
      //  console.log( response.json());
      return response.json();
     })
     .then((data) => {
       const dataEl = data.results;
      //  console.log(dataEl);
       GettingAllData(dataEl);
    
     })
})


// Search Event

search_btn.addEventListener("click", (e) =>{
  imgContainer.innerHTML = "";
  var test = input.value;

  const SearchURL = "https://api.unsplash.com/search/photos/?query="+test+"&per_page=19&client_id=";
  const RandomURL = `https://api.unsplash.com/photos/random/?&per_page=9&client_id=`;
  const api_key = `-GS_BgTXpa7T6831-Gc4UV0oYzU-P6C6OcKKZB5-rNs`;
  // console.log(`${SearchURL}${api_key}`);


  e.preventDefault();
  function GettingAllData(data){
    data.forEach(element => {
      // console.log(element.urls)
      imgContainer.innerHTML += `
      <img src=${element.urls.full} class="image">
      `
    });
  }

 fetch(`${SearchURL}${api_key}`)
     .then(response =>{
      //  console.log( response.json());
      return response.json();
     })
     .then((data) => {
       const dataEl = data.results;
      //  console.log(dataEl);
       GettingAllData(dataEl);
    
     })
})














